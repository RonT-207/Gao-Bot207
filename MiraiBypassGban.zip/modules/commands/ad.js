 module.exports.config = {
	name: "ad",
	version: "1.0.0",
	hasPermssion: 0,
	credits: "Hà Mạc Trường Giang",
	description: "Thông tin về admin",
	commandCategory: "Thông tin về admin",
	cooldowns: 0
};

module.exports.run = ({ event, api }) => api.sendMessage(`\n❌Thông Tin Admin Bot Này❌\nADMIN NAME : Võ Trần Văn Phước\nBiệt Danh: Gao\nGiới Thiệu: Mê Game 🌝\nTính Cách : Hiền vcl không cục súc nhé\nChiều cao : 1m76\nSinh ngày : 03/10/2007\nLiên hệ:+84937642035\nTikTok: gao_pubg\nSở Thích: Thích chơi game\nName Facebook : Phuoc Van (GaoNgu)\nLink Facebook: https://www.facebook.com/profile.php?id=100045873710557\nVài lời tới người dùng BOT: Vui lòng không spam khi sử dụng để tránh die bot. Cảm ơn mọi người đã sử dụng đên con bot của mình.\nLưu ý : Đừng có dại dột mà add 2 bot kẻo bị phát hiện là bạn toang đó <3\nCảnh báo : Vui lòng không dùng bot với mục đích xấu hay cố ý report acc facebook\nChúc bạn sử dụng vui vẻ <3\n=== VTVPGao ===`, event.threadID, event.messageID);
